﻿Namespace Utilities
    Public Class CalcUtility

        Public value1 As Double
        Public value2 As Double

        Public Function AddValues() As Double
            Return value1 + value2
        End Function
        Public Function SubtractValues() As Double
            Return value1 - value2
        End Function
        Public Function MultiplyValues() As Double
            Return value1 * value2
        End Function
        Public Function DivideValues() As Double
            Return value1 / value2
        End Function
    End Class

End Namespace


