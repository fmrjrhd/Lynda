﻿Namespace Utilities
    Public Class CalcUtility
        Public Shared Function AddValues(dbl1 As Double, dbl2 As Double) As Double
            Return dbl1 + dbl2
        End Function
        Public Shared Function SubtractValues(dbl1 As Double, dbl2 As Double) As Double
            Return dbl1 - dbl2
        End Function
        Public Shared Function MultiplyValues(dbl1 As Double, dbl2 As Double) As Double
            Return dbl1 * dbl2
        End Function
        Public Shared Function DivideValues(dbl1 As Double, dbl2 As Double) As Double
            Return dbl1 / dbl2
        End Function
    End Class

End Namespace


