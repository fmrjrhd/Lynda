﻿Module Calculations
    Public Function AddValues(dbl1 As Double, dbl2 As Double) As Double
        Return dbl1 + dbl2
    End Function
    Public Function SubtractValues(dbl1 As Double, dbl2 As Double) As Double
        Return dbl1 - dbl2
    End Function
    Public Function MultiplyValues(dbl1 As Double, dbl2 As Double) As Double
        Return dbl1 * dbl2
    End Function
    Public Function DivideValues(dbl1 As Double, dbl2 As Double) As Double
        Return dbl1 / dbl2
    End Function
End Module
