﻿Module Module1

    Sub Main()
        Console.WriteLine("Hello World")

        Dim value1 = 5
        Dim value2 = 20
        Dim total = value1 + value2
        Console.WriteLine("The result is " + total.ToString)

    End Sub

End Module
